package com.example.diplomaapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
